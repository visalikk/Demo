python mainCode.py #Dataset #inputs #TrainoutputFile #PlotFile #testInput #testOutput #trials #verbose


Sentiment Training: SentimentFinal.py

hypotheticalTesting: SentiSafeBot.sh
