git add .
git commit -m "Done"
git push origin master
